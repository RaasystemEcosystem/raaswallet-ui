// Homepage component
export default function Home() { return <div>Welcome to Raasystem</div>; }