// Contract addresses
export const RAASKOIN = '0x...';